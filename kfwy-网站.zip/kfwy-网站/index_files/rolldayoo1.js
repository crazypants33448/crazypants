var speed1=2//�ٶ���ֵԽ���ٶ�Խ��
rollright1.innerHTML=rollleft1.innerHTML
function Marquee1(){
if(rollright1.offsetWidth-roll1.scrollLeft<=0)
roll1.scrollLeft-=rollleft1.offsetWidth
else{
roll1.scrollLeft++
}
}
var MyMar1=setInterval(Marquee1,speed1)
roll1.onmouseover=function() {clearInterval(MyMar1)}
roll1.onmouseout=function() {MyMar1=setInterval(Marquee1,speed1)}

